import React from 'react';
import { AIChat } from '../components/AIChat';
import { AvailabilityMap } from '../components/AvailabilityMap';

export function Search() {
  return (
    <div className="max-w-7xl mx-auto h-[calc(100vh-9rem)]">
      <div className="grid grid-cols-2 gap-6 h-full">
        <AIChat />
        <AvailabilityMap />
      </div>
    </div>
  );
}