import React from 'react';
import { useStore } from '../lib/store';
import { Settings, CreditCard, Clock, Bell } from 'lucide-react';

export function Profile() {
  const user = useStore((state) => state.user);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="p-8 bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
          <div className="flex items-center gap-6">
            <img
              src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=150&h=150"
              alt="Profile"
              className="w-24 h-24 rounded-full border-4 border-white"
            />
            <div>
              <h1 className="text-2xl font-bold">Dr. Sarah Johnson</h1>
              <p className="text-blue-100">Cardiologist</p>
            </div>
          </div>
        </div>

        <div className="p-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-xl font-semibold mb-4">Profile Settings</h2>
              <div className="space-y-4">
                <button className="w-full flex items-center gap-3 p-4 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                  <Settings className="h-5 w-5 text-gray-500" />
                  <span>Account Settings</span>
                </button>
                <button className="w-full flex items-center gap-3 p-4 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                  <CreditCard className="h-5 w-5 text-gray-500" />
                  <span>Billing & Payments</span>
                </button>
                <button className="w-full flex items-center gap-3 p-4 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                  <Clock className="h-5 w-5 text-gray-500" />
                  <span>Availability</span>
                </button>
                <button className="w-full flex items-center gap-3 p-4 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                  <Bell className="h-5 w-5 text-gray-500" />
                  <span>Notifications</span>
                </button>
              </div>
            </div>

            <div>
              <h2 className="text-xl font-semibold mb-4">Statistics</h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">152</div>
                  <div className="text-gray-600">Total Appointments</div>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">4.9</div>
                  <div className="text-gray-600">Average Rating</div>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">98%</div>
                  <div className="text-gray-600">Response Rate</div>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">24h</div>
                  <div className="text-gray-600">Avg. Response Time</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}