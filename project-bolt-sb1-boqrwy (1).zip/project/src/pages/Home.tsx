import React from 'react';
import { Link } from 'react-router-dom';
import { Search, Calendar, UserCircle } from 'lucide-react';

export function Home() {
  return (
    <div className="max-w-6xl mx-auto">
      <section className="text-center py-20 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-3xl text-white mb-12">
        <h1 className="text-5xl font-bold mb-6">Find Healthcare Professionals</h1>
        <p className="text-xl mb-8">Book appointments with top healthcare providers in your area</p>
        <Link
          to="/search"
          className="bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors"
        >
          Find a Professional
        </Link>
      </section>

      <div className="grid md:grid-cols-3 gap-8 mb-12">
        <div className="bg-white p-8 rounded-xl shadow-sm text-center">
          <Search className="w-12 h-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Smart Search</h3>
          <p className="text-gray-600">Find the right healthcare professional with AI-powered search</p>
        </div>
        <div className="bg-white p-8 rounded-xl shadow-sm text-center">
          <Calendar className="w-12 h-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Easy Booking</h3>
          <p className="text-gray-600">Book appointments instantly with real-time availability</p>
        </div>
        <div className="bg-white p-8 rounded-xl shadow-sm text-center">
          <UserCircle className="w-12 h-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Verified Professionals</h3>
          <p className="text-gray-600">Connect with verified healthcare providers</p>
        </div>
      </div>

      <section className="bg-gray-50 p-12 rounded-xl mb-12">
        <h2 className="text-3xl font-bold mb-8 text-center">Featured Specialties</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {['Cardiology', 'Pediatrics', 'Dermatology', 'Orthopedics'].map((specialty) => (
            <Link
              key={specialty}
              to={`/search?specialty=${specialty}`}
              className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow text-center"
            >
              <h3 className="font-semibold text-lg text-gray-900">{specialty}</h3>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}