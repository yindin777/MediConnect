export interface User {
  id: string;
  email: string;
  role: 'professional' | 'patient';
  name: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  professionalId: string;
  datetime: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  type: 'virtual' | 'in-person';
}

export interface AvailableSlot {
  id: string;
  professionalId: string;
  datetime: string;
  duration: number;
  type: 'virtual' | 'in-person';
  location?: string;
}