import React from 'react';
import { MapPin, Clock } from 'lucide-react';

interface Slot {
  id: string;
  time: string;
  doctor: string;
  specialty: string;
  location: string;
  distance: string;
}

const dummySlots: Slot[] = [
  {
    id: '1',
    time: '10:00 AM',
    doctor: 'Dr. Sarah Johnson',
    specialty: 'Cardiologist',
    location: 'Manhattan Medical Center',
    distance: '0.8 miles'
  },
  {
    id: '2',
    time: '2:30 PM',
    doctor: 'Dr. Michael Chen',
    specialty: 'Pediatrician',
    location: 'Brooklyn Family Clinic',
    distance: '1.2 miles'
  }
];

export function AvailabilityMap() {
  return (
    <div className="bg-white rounded-xl shadow-sm h-full">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold">Available Appointments</h2>
        <p className="text-sm text-gray-600">Showing nearby slots for today</p>
      </div>

      <div className="p-4 space-y-4">
        {dummySlots.map((slot) => (
          <div key={slot.id} className="border border-gray-200 rounded-lg p-4 hover:border-blue-500 transition-colors">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="font-semibold">{slot.doctor}</h3>
                <p className="text-sm text-gray-600">{slot.specialty}</p>
              </div>
              <div className="flex items-center text-blue-600">
                <Clock className="h-4 w-4 mr-1" />
                <span className="text-sm font-medium">{slot.time}</span>
              </div>
            </div>
            <div className="flex items-center text-gray-600">
              <MapPin className="h-4 w-4 mr-1" />
              <span className="text-sm">{slot.location}</span>
              <span className="text-sm text-gray-400 ml-2">({slot.distance})</span>
            </div>
            <button className="mt-3 w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              Book Appointment
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}