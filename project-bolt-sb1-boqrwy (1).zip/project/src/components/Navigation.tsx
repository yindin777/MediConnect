import React from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../lib/store';
import { Stethoscope, UserCircle, Calendar, Search } from 'lucide-react';

export function Navigation() {
  const user = useStore((state) => state.user);

  return (
    <nav className="bg-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Stethoscope className="h-8 w-8 text-blue-600" />
            <span className="text-xl font-bold text-gray-900">MediConnect</span>
          </Link>

          <div className="flex items-center space-x-6">
            <Link to="/search" className="text-gray-600 hover:text-blue-600">
              <Search className="h-5 w-5" />
            </Link>
            <Link to="/appointments" className="text-gray-600 hover:text-blue-600">
              <Calendar className="h-5 w-5" />
            </Link>
            <Link to="/profile" className="text-gray-600 hover:text-blue-600">
              <UserCircle className="h-5 w-5" />
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}