import { HfInference } from '@huggingface/inference';

const hf = new HfInference(import.meta.env.VITE_HUGGINGFACE_API_KEY);

export const getAIResponse = async (input: string) => {
  try {
    const response = await hf.textGeneration({
      model: 'gpt2',
      inputs: input,
      parameters: {
        max_new_tokens: 250,
        temperature: 0.7,
        top_p: 0.95,
      },
    });
    return response.generated_text;
  } catch (error) {
    console.error('Error calling Hugging Face API:', error);
    return 'I apologize, but I encountered an error processing your request. Please try again.';
  }
};